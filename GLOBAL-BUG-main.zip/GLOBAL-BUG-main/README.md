<p align="center">
<a href="https://github.com/GlobalTechInfo"><img title="Author" src="https://i.ibb.co/pndwXMm/anjay-2.jpg?style=for-the-badge&logo=github"></a>
<p>

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

  
<p align="center"><img src="https://profile-counter.glitch.me/{GLOBAL-BUG}/count.svg" alt="Qasim Ali :: Visitor's Count" /></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">



<p align="center">
<a href="https://github.com/GlobalTechInfo/GLOBAL-BUG/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GlobalTechInfo/GLOBAL-BUG?color=blue&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-BUF/network/members"><img title="Forks" src="https://img.shields.io/github/forks/GlobalTechInfo/GLOBAL-BUG?color=red&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-BUG/"><img title="Size" src="https://img.shields.io/github/repo-size/GlobalTechInfo/GLOBAL-BUG?style=flat-square&color=green"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-BUG/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-yellow.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

<p align="center">

  <a aria-label="Join our chats" href="https://t.me/GlobalBotInc" target="_blank">
    <img alt="telegram" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=telegram&logoColor=white" />
  </a>
  

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

### Bot Features 🌅
### Scroll Right To Left

| YT MENU | GROUP MENU | ADD MENU | STORE MENU | IOS BUGS | EMOJI BUGS | CRASH BUGS | WA CRASH | VIP BUGS | TEMP BAN | AI CHATBOT |
| --------| ----------- | --------- | ----------- | -------- | ------- | ------ | ------- | --- | ----- | -------- |
| ✅      |  ✅         |    ✅     |     ✅      |     ✅   |   ✅    |   ✅   |   ✅    |  ✅ |  ✅   |    ✅  |   ✅  | ✅     |


--------


# CLICK ON BELOW BUTTON TO FORK

<a href="https://github.com/GlobalTechInfo/GLOBAL-BUG/fork"><img title="GLOBAL-BUG" src="https://img.shields.io/badge/FORK-GLOBAL BUG-h?color=yellow&style=for-the-badge&logo=stackshare"></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

`Click On Server 1 Button And Wait About 50 To 90 Seconds Website Will Take To Open As Per Renders Free Instance Policy`

 
# GET SESSION CREDS.JSON

<a href='https://necessary-margaretha-oletters-ba309cdc.koyeb.app/' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/PAIRING CODE-1-green?style=for-the-badge&logo=opencv&logoColor=white'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

<a href='https://replit.com/@tlptrends92/GLOBAL-SESSIONS#main.sh' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/PAIRING CODE-2-green?style=for-the-badge&logo=opencv&logoColor=white'/></a>

`Get Creds.json Then Upload It Inside Session Folder Of Forked Repo`

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
# DEPLOY IN REPLIT


   <a href='https://repl.it/github/GlobalTechInfo/GLOBAL-BUG' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
 # DEPLOY TO RENDER

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
   
# DEPLOY IN PANEL
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
<a href='https://bot-hosting.net/?aff=1097457675723341836' target="_blank"><img alt='Panel Link'
src='https://img.shields.io/badge/HOSTING%20PANEL-blue?style=for-the-badge&logo=Cloudflare&logoColor=white'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

  # TUTORIAL FOR PANEL
  <a href="https://youtu.be/TWknrXgt3go?si=aoYd-1Col9T8vtgT"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/TWknrXgt3go?si=aoYd-1Col9T8vtgT" /><br>

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

# DEPLOY IN TERMUX/UBUNTU
```
apt update && apt upgrade -y
```
```
pkg install proot-distro
```
```
proot-distro install ubuntu
```
```
proot-distro login ubuntu
```
```
apt update && apt upgrade -y
```
```
apt install -y webp git ffmpeg curl imagemagick
```
```
apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_lts.x | bash - && apt -y install nodejs
```
```
git clone https://github.com/<your gitHub Username>/GLOBAL-BUG
cd GLOBAL-BUG
```
```
npm install && npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

| [![Qasim Ali](https://github.com/GlobalTechInfo.png?size=100)](https://github.com/GlobalTechInfo) |
| --- |
| [Qasim Ali](https://github.com/GlobalTechInfo) |

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">


[![JOIN WHATSAPP CHANNEL](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">


  
